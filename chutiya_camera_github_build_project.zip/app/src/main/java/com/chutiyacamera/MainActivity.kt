package com.chutiyacamera

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var previewView: PreviewView
    private lateinit var captureButton: Button
    private lateinit var filterSpinner: Spinner
    private var imageCapture: ImageCapture? = null
    private var selectedFilter = 0
    private lateinit var cameraExecutor: ExecutorService

    private val filterNames = listOf(
        "Original", "Warm Glow", "Cool Blue", "Vintage", "Golden Hour", "B&W Classic",
        "Soft Pink", "Cinematic", "Matte", "Vivid", "Dream", "Moody", "Sunset",
        "Ocean", "Forest", "Rose", "Lavender", "Amber", "Silver", "Noir"
    ) + (21..100).map { "Creative Filter $it" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(12, 12, 16))
            setPadding(18, 18, 18, 18)
        }
        val title = TextView(this).apply {
            text = "CHUTIYA CAMERA"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 14)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        root.addView(previewView, LinearLayout.LayoutParams(-1, 0, 1f))

        val filterLabel = TextView(this).apply {
            text = "Choose a filter • 100 styles"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(2, 14, 2, 6)
        }
        root.addView(filterLabel)
        filterSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, filterNames)
            setSelection(0)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedFilter = position
                }
            }
        }
        root.addView(filterSpinner, LinearLayout.LayoutParams(-1, -2))

        captureButton = Button(this).apply {
            text = "●  TAKE PHOTO"
            textSize = 18f
            setOnClickListener { takePhoto() }
        }
        val buttonParams = LinearLayout.LayoutParams(-1, 58).apply { topMargin = 12 }
        root.addView(captureButton, buttonParams)

        val note = TextView(this).apply {
            text = "Select a filter, take a photo, and save it to your gallery."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
            } catch (e: Exception) {
                Toast.makeText(this, "Could not start camera: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: run {
            Toast.makeText(this, "Camera is starting. Try again.", Toast.LENGTH_SHORT).show()
            return
        }
        captureButton.isEnabled = false
        val name = "CHUTIYA_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ChutiyaCamera")
        }
        val options = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onError(exception: ImageCaptureException) {
                captureButton.isEnabled = true
                Toast.makeText(this@MainActivity, "Photo failed: ${exception.localizedMessage}", Toast.LENGTH_LONG).show()
            }
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                val uri = output.savedUri
                if (uri == null || selectedFilter == 0) {
                    captureButton.isEnabled = true
                    Toast.makeText(this@MainActivity, "Saved to Pictures/ChutiyaCamera", Toast.LENGTH_LONG).show()
                    return
                }
                cameraExecutor.execute {
                    try {
                        val input = contentResolver.openInputStream(uri)
                        val bitmap = BitmapFactory.decodeStream(input)
                        input?.close()
                        if (bitmap != null) {
                            val filtered = applyFilter(bitmap, selectedFilter)
                            contentResolver.openOutputStream(uri, "w")?.use { out ->
                                filtered.compress(Bitmap.CompressFormat.JPEG, 95, out)
                            }
                            filtered.recycle()
                            bitmap.recycle()
                        }
                        runOnUiThread {
                            captureButton.isEnabled = true
                            Toast.makeText(this@MainActivity, "Filtered photo saved to gallery!", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            captureButton.isEnabled = true
                            Toast.makeText(this@MainActivity, "Saved original photo; filter could not be applied.", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        })
    }

    private fun applyFilter(src: Bitmap, index: Int): Bitmap {
        val result = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val m = filterMatrix(index)
        paint.colorFilter = ColorMatrixColorFilter(m)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return result
    }

    private fun filterMatrix(i: Int): ColorMatrix {
        val m = ColorMatrix()
        val sat = when (i) {
            5, 19 -> 0f
            9, 10, 14, 15 -> 1.45f
            3, 8, 11 -> 0.72f
            else -> 1.0f + ((i * 7) % 9) * 0.055f
        }
        m.setSaturation(sat)
        val a = when (i) {
            1, 4, 13, 18 -> 1.08f
            2, 14, 19 -> 0.96f
            else -> 1.0f
        }
        val r = when (i) { 1, 4, 12, 17 -> 1.10f; 2, 13, 18 -> 0.92f; else -> 1f }
        val g = when (i) { 2, 13, 14 -> 1.04f; 3, 12, 17 -> 0.96f; else -> 1f }
        val b = when (i) { 2, 13, 16, 19 -> 1.14f; 1, 4, 12, 17 -> 0.88f; else -> 1f }
        val offset = when (i) { 3, 8, 11 -> 10f; 6, 16 -> 8f; 5, 19 -> 0f; else -> ((i * 13) % 17).toFloat() - 8f }
        val tint = ColorMatrix(floatArrayOf(
            r, 0f, 0f, 0f, offset,
            0f, g, 0f, 0f, offset / 2,
            0f, 0f, b, 0f, -offset / 2,
            0f, 0f, 0f, a, 0f
        ))
        m.postConcat(tint)
        return m
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            Toast.makeText(this, "Camera permission is required.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
    }
}
