# CHUTIYA CAMERA

An Android Studio starter project for a simple camera app with 100 selectable photo filter presets.

## Features
- CameraX live camera preview
- Capture photos with the back camera
- 100 selectable filter presets
- Saves photos in `Pictures/ChutiyaCamera`

## Important
Filters are applied to the captured photo after taking it; they are not rendered live over the camera preview yet. This is source code, not a prebuilt APK.

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install the Android SDK 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location. Transfer it to your Android phone and install it.

## Build from a phone with GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this ZIP (not the ZIP file itself) to the repository root.
3. Open the **Actions** tab and enable workflows if GitHub asks.
4. Choose **Build CHUTIYA CAMERA APK** and tap **Run workflow** (or wait for the first push workflow).
5. When the run finishes successfully, open it and download `chutiya-camera-debug-apk` under Artifacts.
